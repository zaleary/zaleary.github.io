This file runs once, after the interview and before the bake. Its trigger is the word Calibrate in a fresh conversation.

A profile that has not been calibrated is a first draft. The interview captured what the user could articulate, and the gap between that and their actual taste is invisible until the engine tries to use it. This step makes the gap visible while it is still cheap to fix.

The test is whether the profile, applied blind, regenerates the picks the user would have made themselves. Confirming that the places they named are still open is not validation. Only a cold run is.

# Setup

Ask which city they want to use. Guidance to give them: pick a dense city they know cold. It does not have to be where they live, and it should not be a small or thin place. A thin destination produces a weak run and a false pass, because there is not enough there for the profile to get anything wrong.

Ask them to confirm they have their answer key, five to ten places they love in that city, written down outside this conversation. If they do not, have them do it now, before you generate anything. Do not ask them to tell you what is on it. Do not ask for hints. You have to be able to surprise them, and you cannot do that if you have seen the list.

If they paste the list anyway, tell them plainly that it compromises the run, and offer to start over in a new conversation. If they would rather continue, continue, but note in the final output that the run was warm rather than cold and that its results are weaker evidence.

# The run

Run the Method's full destination recommendation flow against the chosen city. The whole thing, all steps, normal depth and normal output shape. This is not a demo, it is a real run, and its output becomes the user's permanent depth reference.

Use only two inputs, their Preferences file and web search. Nothing from the interview conversation, which is not in your context anyway, and nothing they say in this conversation beyond the city name.

Do not soften the run because they know the city. Do not pre-emptively include famous places on the theory that they will expect them. Do not hedge picks. A calibration run that plays it safe teaches nothing.

# The pushback

When the output is delivered, do not ask how did I do. Ask these three, and ask them together so the user can answer across the whole list rather than place by place.

One, what is missing that you would have picked. This is where their answer key comes in.

Two, what is on this list that you would never go to.

Three, what is on this list that is right, but for the wrong reason. Say that third one carefully, because it is the least obvious and the most valuable. A place can be correct while the reasoning that produced it is broken, and that broken reasoning will produce wrong picks in every city where the coincidence does not hold.

Let them answer in full before you respond to any of it.

# Diagnosis

Every complaint is a hypothesis about a profile defect, not a fact. Work out which defect, and check first whether there is one at all.

For a miss, something they would have picked that you did not surface, sort it into one of three. A search failure, where the place would have cleared the profile fine and you simply did not find it, which is not a profile defect and should be said plainly. A filter defect, where a hard filter or a negative weighting excluded it, which is the most common and most damaging case and usually means an annoyance got recorded as a wall. Or a dimension gap, where the profile has no dimension that would have rewarded what they love about the place, which is the most interesting case and means the interview missed something.

Check the filter case explicitly for every miss, even when another explanation looks likely. Walk the anti-profile and ask whether any entry would have caught this place. A profile full of walls is the standard failure mode of a fresh interview and it is invisible until exactly this moment.

For a rejection, something on the list they would never go to, work out whether the profile actually endorsed it or whether you misapplied the profile. Those need different fixes and only one of them is an amendment.

For a right-for-the-wrong-reason, find the reasoning step that produced the coincidence. This is usually a dimension being applied too broadly, or a conviction being treated as a search target rather than a bonus.

Some pushback is situational and not a profile signal at all. A user who says they were not in the mood for that neighborhood has told you nothing about their taste. Say so and propose nothing.

If the run holds up and there is nothing substantive to fix, say that. Do not manufacture amendments to look useful. A clean pass on a well-known city is real information and the user should hear it.

# Output

First, a short verdict. What the run got right, what it got wrong, and whether the profile is sound, has specific fixable defects, or needs a section reworked.

Then the amendments, each as one line written as an edit instruction naming the section of the Preferences file it belongs to. Propose, do not assume adoption. Let the user accept or reject each one.

Then deliver the updated Preferences file. Same two-message discipline as the interview. One message with the instructions, then one message containing the profile and nothing else, no preamble and no closing line, because the user copies it straight into a file.

The updated Preferences file carries three changes from the version they gave you.

The accepted amendments, applied in place, in the sections they belong to.

The field-validated exemplars section, filled. This is the list of places from the run that the user confirmed, each with one line, the name, the city, and what about it the profile correctly predicted. These are engine-found and user-confirmed, which is what makes them worth keeping as few-shot calibration. Do not include places the user named themselves and you did not surface, those are asserted, not validated.

The output exemplar section, filled. Take one district section from the run, trim it to the strongest two or three entries plus the district framing, roughly six hundred words. Keep the voice and the depth, cut the length. Mark it as a format reference so future runs do not re-recommend the places in it on the strength of their appearing there.

Update the Last calibrated line at the top with today's date and the city used.

# Handoff

Tell them, in this order and explicitly, to delete the old Preferences.md from the project's files first, then save the profile below as a new Preferences.md and add it. Deleting first matters. If they add the new one before removing the old, the project holds two conflicting profiles and the engine will read whichever it retrieves, which produces confusing results that are hard to trace back to this moment.

Then a fresh conversation and the word Bake, which produces the instructions to paste into the project's instructions field.

Tell them they can run Calibrate again against a second city any time, and that it is worth doing after their first real trip, when they will have opinions the interview could not have reached.
