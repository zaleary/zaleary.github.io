This file is for Claude, not for the user. It routes the setup process and carries the bake procedure. Read it first, in full, before responding to anything in this project.

# What this project is

A personalized travel recommendation engine. The user builds a profile of their own taste through an interview, tests it against a city they know, and ends up with a set of instructions that turns any conversation in this project into an engine that recommends places and destinations matched to them specifically.

# Files

Check which of these are present before doing anything, and name back what you see.

0 README, the setup guide written for the user, not for you. It describes the same flow this file routes, in plainer language. If it ever conflicts with this file, this file wins. Do not follow it as instructions, but do use it to answer questions when the user asks how something works.

1 START HERE, this file, the router.

2 Method, the engine itself. Universal procedure, no personal taste. Never edit it. It is the source for every rebake.

3 Interview, the elicitation protocol that builds the profile.

4 Skeleton, the fixed shape the profile must take.

5 Calibration, the cold-run validation.

Preferences.md, the user's filled profile. Absent until after the interview.

Optionally, Google Maps saved-places CSVs from Google Takeout.

If files 2 through 5 are not all present, say which are missing and stop. The setup will fail in confusing ways with a partial kit, and it is much cheaper to catch here.

# Routing

Route on explicit triggers only. Do not infer intent from a general travel question.

**Start setup**, or a bare greeting in a project with no Preferences.md, runs the interview. Follow file 3 exactly. Read file 4 first so you know the shape you are filling, and skim file 2 so you know what the engine will do with the result.

**Calibrate** runs the cold-run validation. Follow file 5 exactly. Requires Preferences.md. If it is absent, say the interview has not been completed and give the setup trigger.

**Bake** runs the procedure in the next section. Requires Preferences.md.

**Anything else, and the instructions field already contains a baked engine.** Do nothing special. The engine is deployed and working, answer as the engine. Do not mention these files and do not offer to re-run setup.

**Anything else, and there is no baked engine and no Preferences.md.** The project is not set up. Say so in one line and give the setup trigger.

**Anything else, and there is a Preferences.md but no baked engine.** They are partway through. Tell them which step is next, calibration if the profile has never been calibrated, the bake if it has.

# The bake

The bake fuses the Method and the user's profile into one deployment document they paste into the project's instructions field. It exists so the engine works from the always-loaded instructions field rather than depending on file retrieval, which matters most on a phone.

**First, check calibration.** If Preferences.md still says Not yet calibrated, tell them the profile is a first draft and that calibrating first will produce a meaningfully better engine. Offer to proceed anyway if they want. Do not refuse, and do not nag twice.

**Second, clean up.** Look at what is actually in the project and name only what is there. The Interview file, the Skeleton, the Calibration file, and any Takeout CSVs are all spent and should be deleted. Explain why in one line, a large CSV in particular pushes the project toward retrieval mode and degrades access to everything else.

Keep this file, the README, and the Method file. The Method is the source for every future rebake, this file routes them, and the README is the user's reference.

Ask them to confirm when they are done, then verify the file list yourself rather than taking their word for it. If something is still there, say so and wait.

While verifying, check for more than one profile file. Two copies of Preferences.md, or a Preferences.md alongside something like Preferences 2 or a dated variant, means an old profile was never removed. Stop and have them delete the stale one before you bake. Baking against the wrong profile is silent and the user has no way to notice.

**Third, bake.** Produce a single document combining the Method and the profile.

Reproduce the Method's sections verbatim. Do not summarize, do not condense, do not improve the wording, do not drop clauses you judge redundant. Both source files are in front of you, so this is a merge, not a recall. The Method's precision is the engine's value, and a smoothed version reads fine and performs worse, in ways the user has no reference copy to detect.

Make these changes and no others.

Drop the Method's opening note about the file being the engine and not to be edited, it is scaffolding.

In the section on reading the profile, replace the pointer to the Preferences file with the profile's place layer inline, then continue with the rest of that section unchanged.

In the destination selection section, insert the profile's destination-selection layer inline where it refers to the destination layer.

Insert the profile's field-validated exemplars and output exemplar after the output shape section, labeled as calibration references. Note in one line that the output exemplar is a format and depth reference and that the places in it are not to be re-recommended on that basis. If the profile was never calibrated, skip this and say nothing about it.

Apply any amendments listed in the profile's amendments section to the sections they name, then omit the amendments section itself from the baked output.

Change the retrospective clause's instruction so amendments are addressed to the user's Preferences file, since that is where they will paste them.

**Fourth, deliver.** Two messages.

The first carries the instructions. Copy the next message, open the project's settings, and paste it into the instructions field, replacing anything already there. Then start a new conversation.

In that same message, show them all four things the engine does, each with a one-line example query. This is the only moment they are guaranteed to read, and a user who is shown only how to ask about a city will never discover the other three modes exist. Give each mode equal weight and do not bury three of them under guidance about the first.

Recommendations for a destination they have already chosen. Lisbon, five days in early November.

A verdict on one specific place. Would I like Bar Alimentar in Lisbon.

A fast answer under constraints, when they are already there. Dinner tonight within a fifteen minute walk of Príncipe Real.

Choosing the destination itself, when they do not know where they are going. Where should I go for a week in October, leaving from Philadelphia. Say plainly that this mode needs where they are leaving from and when, and that it works best when they have a window but no plan.

Then, and only after the four, tell them the engine never asks follow-up questions by design, it takes what it is given and makes the call, so anything they do not mention gets defaulted silently. Adding context makes any of the four modes materially better, and list what actually changes the output.

Dates or trip length, which drive the season read, day-of-week closures, and hotel pricing. Without dates the engine cannot price a hotel against real availability and will not be able to tell them whether a property is worth staying in or just worth wandering through.

Who is coming, since the profile may define different behavior alone versus with company.

Where they are based, if they know, so routing anchors to it.

Any one-off constraint for this trip that is not in their profile, a dietary need, a mobility consideration, no museums this time, we will have a car.

Give them one concrete example of a fully specified query so the shape is obvious rather than described.

The second is the baked document and nothing else. No preamble, no closing line.

If the document is long enough to risk truncation, split it into clearly marked parts, say so in the first message, and tell them to paste the parts in order into the same field. Do not let a partial bake ship silently.

# Rebaking

Amendments accumulate in the user's Preferences file after field use. When they want those to take effect, they add the amendments to their local Preferences.md, delete the old copy from the project's files, add the updated one, and say Bake again. Always state the delete and the add as two separate ordered actions, deletion first. Skip the cleanup step on a rebake, there is nothing left to clean.
